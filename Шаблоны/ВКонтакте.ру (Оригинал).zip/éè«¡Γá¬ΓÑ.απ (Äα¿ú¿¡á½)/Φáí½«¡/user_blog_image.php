<?
$page = "user_blog_image";
include "header.php";


// ASSIGN VARIABLES AND SHOW BLOG ENTRY IMAGE ADDITION PAGE
include "footer.php";
?>