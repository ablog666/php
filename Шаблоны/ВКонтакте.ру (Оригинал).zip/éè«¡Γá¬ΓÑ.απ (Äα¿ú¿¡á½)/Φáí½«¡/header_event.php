<?


// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE EVENT LANGUAGE FILE
include "./lang/lang_".$global_lang."_event.php";

// INCLUDE EVENT CLASS FILE
include "./include/class_event.php";

// INCLUDE EVENT FUNCTION FILE
include "./include/functions_event.php";

?>