<?
$page = "help";
include "header.php";

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>
