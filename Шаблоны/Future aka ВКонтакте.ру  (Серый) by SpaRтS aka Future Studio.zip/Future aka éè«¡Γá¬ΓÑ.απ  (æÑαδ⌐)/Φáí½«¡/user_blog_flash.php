<?
$page = "user_blog_flash";
include "header.php";


  
// ASSIGN VARIABLES AND SHOW BLOG ENTRY FLASH ADDITION PAGE
include "footer.php";
?>