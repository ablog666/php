<?
$page = "user_blog_link";
include "header.php";


// ASSIGN VARIABLES AND SHOW BLOG ENTRY LINK ADDITION PAGE
include "footer.php";
?>