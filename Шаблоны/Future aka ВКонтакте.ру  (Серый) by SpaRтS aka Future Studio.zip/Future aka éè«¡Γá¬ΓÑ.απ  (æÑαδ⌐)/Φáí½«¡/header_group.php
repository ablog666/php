<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE GROUP LANGUAGE FILE
include "./lang/lang_".$global_lang."_group.php";

// INCLUDE GROUP CLASS FILE
include "./include/class_group.php";

// INCLUDE GROUP FUNCTION FILE
include "./include/functions_group.php";

?>