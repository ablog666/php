window.onload=function(){
Nifty("ul.tabs a","small top");
Nifty("ul.buttonRow a","small");
Nifty("div.leftAd","small transparent");
Nifty("div.selPad","small transparent");
Nifty("div.myPad","small transparent");
}
