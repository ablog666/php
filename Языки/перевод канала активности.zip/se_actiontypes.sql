-- phpMyAdmin SQL Dump
-- version 2.8.1
-- http://www.phpmyadmin.net
-- 
-- Хост: mysql009.infobox.ru
-- Время создания: Апр 13 2008 г., 11:06
-- Версия сервера: 5.0.32
-- Версия PHP: 4.3.10-19
-- 
-- БД: `freestudents_a`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблицы `se_actiontypes`
-- 

CREATE TABLE `se_actiontypes` (
  `actiontype_id` int(9) NOT NULL auto_increment,
  `actiontype_name` varchar(50) NOT NULL default '',
  `actiontype_icon` varchar(50) NOT NULL default '',
  `actiontype_desc` varchar(250) NOT NULL default '',
  `actiontype_enabled` int(1) NOT NULL default '0',
  `actiontype_text` text NOT NULL,
  PRIMARY KEY  (`actiontype_id`),
  UNIQUE KEY `actiontype_name` (`actiontype_name`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=24 ;

-- 
-- Дамп данных таблицы `se_actiontypes`
-- 

INSERT INTO `se_actiontypes` VALUES (1, 'вход', 'action_login.gif', 'Когда я вхожу в систему.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; вошел(а).');
INSERT INTO `se_actiontypes` VALUES (2, 'редактирование фото', 'action_editphoto.gif', 'Когда я обновляю свое фото.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; обновил(а) свое фото.&lt;div style=&#039;padding: 10px 10px 10px 20px;&#039;&gt;&lt;a href=&#039;profile.php?user=[username]&#039;&gt;&lt;img src=&#039;[photo]&#039; border=&#039;0&#039;&gt;&lt;/a&gt;&lt;/div&gt;');
INSERT INTO `se_actiontypes` VALUES (3, 'редактирование профайл', 'action_editprofile.gif', 'Когда я обновляю свой профайл.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; обновил(а) свой профиль.');
INSERT INTO `se_actiontypes` VALUES (4, 'написание комментария', 'action_postcomment.gif', 'Когда я комментирую чейто профайл.', 1, '&lt;a href=&#039;profile.php?user=[username1]&#039;&gt;[username1]&lt;/a&gt; написал(а) коментарий в профайле пользователя &lt;a href=&#039;profile.php?user=[username2]&#039;&gt;[username2]&lt;/a&gt; комментарий:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt;');
INSERT INTO `se_actiontypes` VALUES (5, 'добавление друзей', 'action_addfriend.gif', 'Когда я добавляю друзей', 1, '&lt;a href=&#039;profile.php?user=[username1]&#039;&gt;[username1]&lt;/a&gt; и &lt;a href=&#039;profile.php?user=[username2]&#039;&gt;[username2]&lt;/a&gt; теперь друзья.');
INSERT INTO `se_actiontypes` VALUES (6, 'регистрация', 'action_signup.gif', 'Регистрация', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; зарегистрировался.');
INSERT INTO `se_actiontypes` VALUES (7, 'изменения статуса', 'action_editstatus.gif', 'Когда я изменяю свой статус.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; статус: [status]');
INSERT INTO `se_actiontypes` VALUES (8, 'postblog', 'action_postblog.gif', 'Когда я оставляю запись в блоге.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; оставил(а) новую запись в блоге: &lt;a href=&#039;blog_entry.php?user=[username]&amp;blogentry_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (9, 'blogcomment', 'action_postcomment.gif', 'Когдя я комментирую запись в блоге.', 1, '&lt;a href=&#039;profile.php?user=[username1]&#039;&gt;[username1]&lt;/a&gt; оставил(а) комментарий к &lt;a href=&#039;blog_entry.php?user=[username2]&amp;blogentry_id=[id]&#039;&gt;записи&lt;/a&gt;:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt; &lt;a href=&#039;profile.php?user=[username2]&#039;&gt;[username2]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (10, 'newalbum', 'action_newalbum.gif', 'Когда я создаю новый альбом.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; создал(а) новый альбом: &lt;a href=&#039;album.php?user=[username]&amp;album_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (11, 'newmedia', 'action_newmedia.gif', 'Когда я загружаю новый фотографии.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; добавил(а) в свой альбом новую фотографию: &lt;a href=&#039;album.php?user=[username]&amp;album_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (12, 'mediacomment', 'action_postcomment.gif', 'Когда я комментирую фотографию.', 1, '&lt;a href=&#039;profile.php?user=[username1]&#039;&gt;[username1]&lt;/a&gt; оставил комментарий к &lt;a href=&#039;album_file.php?user=[username2]&amp;album_id=[albumid]&amp;media_id=[mediaid]&#039;&gt;фотографии&lt;/a&gt;:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt; &lt;a href=&#039;profile.php?user=[username2]&#039;&gt;[username2]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (13, 'newevent', 'action_newevent.gif', 'Когда я создаю встречу.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; организует новую встречу: &lt;a href=&#039;event.php?event_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (14, 'attendevent', 'action_attendevent.gif', 'Когда я собираюсь на встречу.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; собирается участвовать во встрече: &lt;a href=&#039;event.php?event_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (15, 'eventcomment', 'action_postcomment.gif', 'Когда я комментирую встречу.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; оставил комментарий по поводу встречи &lt;a href=&#039;event.php?event_id=[id]&#039;&gt;[title]&lt;/a&gt;:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div');
INSERT INTO `se_actiontypes` VALUES (16, 'eventmediacomment', 'action_postcomment.gif', 'Когда я комментирую фотографию во встрече.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; оставил комментарий к &lt;a href=&#039;event_album_file.php?event_id=[id]&amp;eventmedia_id=[id2]&#039;&gt;фотографии&lt;/a&gt; со встречи &lt;a href=&#039;event.php?event_id=[id]&#039;&gt;[title]&lt;/a&gt;:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt;');
INSERT INTO `se_actiontypes` VALUES (17, 'newgroup', 'action_newgroup.gif', 'Когда я создаю группу.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; создал новую группу: &lt;a href=&#039;group.php?group_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (18, 'joingroup', 'action_joingroup.gif', 'Когда я присоединяюсь к группе.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; вошел в группу: &lt;a href=&#039;group.php?group_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (19, 'leavegroup', 'action_leavegroup.gif', 'Когда я покидаю группу.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; покинул группу: &lt;a href=&#039;group.php?group_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (20, 'groupcomment', 'action_postcomment.gif', 'Когда я комментирую в группе.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; posted a comment on the group &lt;a href=&#039;group.php?group_id=[id]&#039;&gt;[title]&lt;/a&gt;:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt;');
INSERT INTO `se_actiontypes` VALUES (21, 'groupmediacomment', 'action_postcomment.gif', 'Когда я комментирую фотографию в группе.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; оставил комментарий к &lt;a href=&#039;group_album_file.php?group_id=[id]&amp;groupmedia_id=[id2]&#039;&gt;фотографии&lt;/a&gt; в группе &lt;a href=&#039;group.php?group_id=[id]&#039;&gt;[title]&lt;/a&gt;&#039;s:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt;');
INSERT INTO `se_actiontypes` VALUES (22, 'postclassified', 'action_postclassified.gif', 'Когда я создаю объявление.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; разметил(а) объявление: &lt;a href=&#039;classified.php?user=[username]&amp;classified_id=[id]&#039;&gt;[title]&lt;/a&gt;');
INSERT INTO `se_actiontypes` VALUES (23, 'classifiedcomment', 'action_postcomment.gif', 'Когда я комментирую объявление.', 1, '&lt;a href=&#039;profile.php?user=[username1]&#039;&gt;[username1]&lt;/a&gt; прокомментировал(а) &lt;a href=&#039;classified.php?user=[username2]&amp;classified_id=[id]&#039;&gt;объявление&lt;/a&gt; &lt;a href=&#039;profile.php?user=[username2]&#039;&gt;[username2]&lt;/a&gt;&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt;');
